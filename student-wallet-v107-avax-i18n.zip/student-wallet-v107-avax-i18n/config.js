// Dán khóa Publishable của bạn vào SUPABASE_ANON_KEY (Settings > API Keys > Publishable key > nút copy).
// KHÔNG dán khóa Secret (sb_secret_...) vào đây.
window.SUPABASE_URL = 'https://tqoqncejdqssutmzsknv.supabase.co';
window.SUPABASE_ANON_KEY = 'sb_publishable_hmMD9QBRlOzAI5Oo-o8Hjg_JG190N3R';

// Địa chỉ Smart Contract StudentGroupVaultV4 mặc định trên Avalanche Fuji Testnet
window.VAULT_CONTRACT_ADDRESS = '0xA83681B88c175eF1d73224002989D0F64bA45aa6';
window.DEFAULT_VAULT_CONTRACT_ADDRESS = window.VAULT_CONTRACT_ADDRESS;
